# DESKTOP MODE PRO MAX – UNIVERSAL EDITION

Proyek Android Studio ini berisi implementasi Desktop Environment universal untuk berbagai merek smartphone Android.

## Otomatisasi GitHub Actions (APK Auto-Build)
Proyek ini sudah dilengkapi dengan file `.github/workflows/build.yml`. 
Cukup upload seluruh isi folder ke repository GitHub kamu, lalu buka tab **Actions** di GitHub untuk mengunduh APK yang otomatis di-build!
