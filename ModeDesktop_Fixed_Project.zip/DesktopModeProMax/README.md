# MODE DESKTOP

Aplikasi Android desktop-style sederhana berbasis Jetpack Compose.

## Build APK melalui GitHub Actions

1. Upload **seluruh isi folder `DesktopModeProMax`** ke root repository GitHub.
2. Pastikan `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, dan folder `app/` berada di root repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build Mode Desktop APK**.
5. Jalankan **Run workflow** atau push commit baru.
6. Setelah berhasil, buka hasil workflow dan unduh artifact `Mode-Desktop-Debug-APK`.

Workflow ini memasang Gradle 8.7 langsung di GitHub Actions sehingga tidak membutuhkan file `gradlew`.

## Catatan

- Minimum Android: Android 8.0 (API 26).
- Target SDK: 34.
- Fitur desktop eksternal tergantung dukungan hardware dan Android pada perangkat.
- Proyek ini adalah desktop-style launcher/app, bukan pengganti sistem operasi Android.
- File Explorer saat ini hanya dapat membaca lokasi yang memang dapat diakses Android; akses penyimpanan penuh memerlukan pemilih folder/izin tambahan.
