package com.lin.desktopmodepro

import android.app.Application

class DesktopApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
