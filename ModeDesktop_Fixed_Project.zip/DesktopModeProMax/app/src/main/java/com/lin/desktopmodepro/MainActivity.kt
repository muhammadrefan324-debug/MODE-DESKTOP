package com.lin.desktopmodepro

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import com.lin.desktopmodepro.ui.desktop.DesktopScreen
import com.lin.desktopmodepro.ui.theme.DesktopModeProMaxTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DesktopModeProMaxTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DesktopScreen(
                        onOpenExplorer = {
                            startActivity(Intent(this, com.lin.desktopmodepro.ui.explorer.FileExplorerActivity::class.java))
                        },
                        onOpenDiagnostics = {
                            startActivity(Intent(this, com.lin.desktopmodepro.ui.diagnostics.DiagnosticsActivity::class.java))
                        },
                        onExitDesktop = {
                            finish()
                        }
                    )
                }
            }
        }
    }
}
