package com.lin.desktopmodepro.data

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

data class AppItem(
    val packageName: String,
    val appName: String,
    val icon: Drawable?,
    val category: String
)

object AppRepository {
    fun getInstalledApps(context: Context): List<AppItem> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        return resolveInfos.map { resolveInfo ->
            val packageName = resolveInfo.activityInfo.packageName
            val appName = resolveInfo.loadLabel(pm).toString()
            val icon = resolveInfo.loadIcon(pm)
            AppItem(
                packageName = packageName,
                appName = appName,
                icon = icon,
                category = "General"
            )
        }.sortedBy { it.appName }
    }
}
