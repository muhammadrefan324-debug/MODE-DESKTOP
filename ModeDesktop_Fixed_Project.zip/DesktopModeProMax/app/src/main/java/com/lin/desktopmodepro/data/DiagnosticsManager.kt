package com.lin.desktopmodepro.data

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Environment
import android.os.StatFs

data class DeviceReport(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val totalRamMB: Long,
    val freeStorageGB: Double,
    val externalDisplaySupported: Boolean,
    val desktopWindowingSupported: Boolean,
    val otgSupported: Boolean
)

object DiagnosticsManager {
    fun getDeviceReport(context: Context): DeviceReport {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val memoryInfo = android.app.ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        val totalRam = memoryInfo.totalMem / (1024 * 1024)

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeStorage = stat.availableBlocksLong * stat.blockSizeLong.toDouble() / (1024 * 1024 * 1024)

        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val displays = displayManager.displays
        val hasExternal = displays.size > 1

        val desktopWindowing = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val otgSupported = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_USB_HOST)

        return DeviceReport(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            totalRamMB = totalRam,
            freeStorageGB = String.format("%.2f", freeStorage).toDouble(),
            externalDisplaySupported = hasExternal,
            desktopWindowingSupported = desktopWindowing,
            otgSupported = otgSupported
        )
    }
}
