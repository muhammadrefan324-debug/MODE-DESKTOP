package com.lin.desktopmodepro.ui.desktop

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.drawablepainter.rememberDrawablePainter
import com.lin.desktopmodepro.data.AppItem
import com.lin.desktopmodepro.data.AppRepository

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DesktopScreen(
    onOpenExplorer: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onExitDesktop: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var showStartMenu by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        apps = AppRepository.getInstalledApps(context)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(80.dp),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    DesktopIcon(label = "File Explorer", iconId = android.R.drawable.ic_menu_agenda) {
                        onOpenExplorer()
                    }
                }
                item {
                    DesktopIcon(label = "Diagnostics", iconId = android.R.drawable.ic_menu_info_details) {
                        onOpenDiagnostics()
                    }
                }
                item {
                    DesktopIcon(label = "Exit Desktop", iconId = android.R.drawable.ic_menu_close_clear_cancel) {
                        onExitDesktop()
                    }
                }

                items(apps) { app ->
                    val drawablePainter = rememberDrawablePainter(drawable = app.icon)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.combinedClickable(
                            onClick = {
                                val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                                launchIntent?.let { context.startActivity(it) }
                            }
                        ).padding(4.dp)
                    ) {
                        Image(
                            painter = drawablePainter,
                            contentDescription = app.appName,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = app.appName,
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        TaskbarComponent(
            modifier = Modifier.align(Alignment.BottomCenter),
            onStartClick = { showStartMenu = !showStartMenu },
            onControlCenterClick = { }
        )
    }
}

@Composable
fun DesktopIcon(label: String, iconId: Int, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(4.dp)
    ) {
        IconButton(onClick = onClick) {
            Icon(
                painter = painterResource(id = iconId),
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}
