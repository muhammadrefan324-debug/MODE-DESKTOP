package com.lin.desktopmodepro.ui.desktop

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TaskbarComponent(
    modifier: Modifier = Modifier,
    onStartClick: () -> Unit,
    onControlCenterClick: () -> Unit
) {
    val currentTime = rememberCurrentTime()

    Surface(
        modifier = modifier.fillMaxWidth().height(56.dp),
        color = Color(0xFF1E1E1E).copy(alpha = 0.95f),
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = onStartClick) {
                    Icon(
                        painter = painterResource(id = android.R.drawable.ic_menu_compass),
                        contentDescription = "Start Menu",
                        tint = Color(0xFF60CDFF)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = onControlCenterClick) {
                    Text(text = currentTime, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun rememberCurrentTime(): String {
    val calendar = Calendar.getInstance()
    val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    return formatter.format(calendar.time)
}
