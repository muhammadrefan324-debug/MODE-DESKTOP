package com.lin.desktopmodepro.ui.diagnostics

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lin.desktopmodepro.data.DeviceReport
import com.lin.desktopmodepro.data.DiagnosticsManager
import com.lin.desktopmodepro.ui.theme.DesktopModeProMaxTheme

class DiagnosticsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = DiagnosticsManager.getDeviceReport(this)

        setContent {
            DesktopModeProMaxTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DiagnosticsScreen(report = report, onBack = { finish() })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsScreen(report: DeviceReport, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Device Compatibility & Diagnostics") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { DiagnosticItem("Manufacturer", report.manufacturer) }
            item { DiagnosticItem("Device Model", report.model) }
            item { DiagnosticItem("Android Version", "${report.androidVersion} (SDK ${report.sdkInt})") }
            item { DiagnosticItem("Total RAM", "${report.totalRamMB} MB") }
            item { DiagnosticItem("Free Storage", "${report.freeStorageGB} GB") }
            item { DiagnosticItem("External Display Support", if (report.externalDisplaySupported) "AVAILABLE" else "NOT SUPPORTED (No secondary display detected)") }
            item { DiagnosticItem("Desktop Windowing Support", if (report.desktopWindowingSupported) "SUPPORTED" else "LIMITED") }
            item { DiagnosticItem("USB OTG Support", if (report.otgSupported) "SUPPORTED" else "NOT SUPPORTED") }
        }
    }
}

@Composable
fun DiagnosticItem(label: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium)
            Text(text = value, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
