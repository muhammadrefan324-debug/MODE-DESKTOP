package com.lin.desktopmodepro.ui.explorer

import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lin.desktopmodepro.ui.theme.DesktopModeProMaxTheme
import java.io.File

class FileExplorerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rootDir = Environment.getExternalStorageDirectory()

        setContent {
            DesktopModeProMaxTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FileExplorerScreen(initialDir = rootDir, onBack = { finish() })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileExplorerScreen(initialDir: File, onBack: () -> Unit) {
    var currentDir by remember { mutableStateOf(initialDir) }
    val files = remember(currentDir) {
        currentDir.listFiles()?.toList() ?: emptyList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = currentDir.absolutePath) },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (currentDir.parentFile != null) {
                item {
                    Button(onClick = { currentDir = currentDir.parentFile!! }) {
                        Text(".. (Parent Directory)")
                    }
                }
            }
            items(files) { file ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (file.isDirectory && file.canRead()) {
                            currentDir = file
                        }
                    }
                ) {
                    Text(
                        text = if (file.isDirectory) "[DIR] ${file.name}" else file.name,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}
