package com.lin.desktopmodepro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF60CDFF),
    secondary = Color(0xFF202020),
    background = Color(0xFF121212),
    surface = Color(0xFF1E1E1E)
)

@Composable
fun DesktopModeProMaxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
